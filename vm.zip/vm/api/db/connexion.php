<?php

$server = "localhost";
$username = "root";
$password = "password";
$db = "libvirt";
$conn = mysqli_connect($server, $username, $password, $db);
